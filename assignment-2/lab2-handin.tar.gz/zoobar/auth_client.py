from debug import *
from zoodb import *
import rpclib

def login(username, password):
    ## Fill in code here.
    socket = "/authsvc/sock"
    args = { "username": username, "password": password }
    with rpclib.client_connect(socket) as r:
        return r.call("login", **args)

def register(username, password):
    ## Fill in code here.
    socket = "/authsvc/sock"
    args = { "username": username, "password": password }
    with rpclib.client_connect(socket) as r:
        return r.call("register", **args)
    

def check_token(username, token):
    ## Fill in code here.
    socket = "/authsvc/sock"
    args = { "username": username, "token": token }
    with rpclib.client_connect(socket) as r:
        return r.call("check_token", **args)
