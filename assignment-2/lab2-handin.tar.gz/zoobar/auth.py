from zoodb import *
from debug import *

import hashlib
import random
import pbkdf2
import os

def newtoken(db, cred):
    hashinput = "%s%.10f" % (cred.password, random.random())
    cred.token = hashlib.md5(hashinput).hexdigest()
    db.commit()
    return cred.token

def login(username, password):
    db = cred_setup()
    cred = db.query(Cred).get(username)
    if not cred:
        return None
    if cred.password == pbkdf2.PBKDF2(password, cred.salt).hexread(32):
        return newtoken(db, cred)
    else:
        return None

def register(username, password):
    p_db = person_setup()
    c_db = cred_setup()
    person = p_db.query(Person).get(username)
    if person:
        return None
    newperson = Person()
    newcred = Cred()
    newperson.username = username
    newcred.username = username
    newcred.salt = os.urandom(8).decode("latin-1")
    newcred.password = pbkdf2.PBKDF2(password, newcred.salt).hexread(32)
    p_db.add(newperson)
    c_db.add(newcred)
    p_db.commit()
    c_db.commit()
    return newtoken(c_db, newcred)

def check_token(username, token):
    db = cred_setup()
    cred = db.query(Cred).get(username)
    if cred and cred.token == token:
        return True
    else:
        return False

